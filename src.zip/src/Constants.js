export const BASE_URL = 'https://api.themoviedb.org/3';
export const API_KEY = 'api_key=9b500945c4d684c179ae552830ece300&';
