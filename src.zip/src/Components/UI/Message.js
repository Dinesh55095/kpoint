function Message({ text }) {
    return (
        <p className="message text-center">{text}</p>
    )
}

export default Message;