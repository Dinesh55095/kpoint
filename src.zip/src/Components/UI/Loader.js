import './Loader.css'

function Loader() {
    return (
        <div className="Lodermain">
            <div class="loader"></div>
        </div>
    )
}

export default Loader;